#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtGlobal>
#include <QtCore>
#include <QtGui>
#include <QApplication>
#include <QGraphicsObject>
#include <QGraphicsScene>
#include <QtGlobal>
#include <QMessageBox>
#include <QList>
#include <QImage>
#include <QDialog>
#include <QtDebug>
#include <QLinearGradient>
#include <QRadialGradient>
#include <QConicalGradient>
#include "ellipticfixedsize.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private slots:
    void on_spButton_clicked();

    void on_closeButton_clicked();

    void on_cleanButton_clicked();

    void on_drPlateButton_clicked();

    void on_sDiamEdit_textChanged(const QString &arg1);

    void on_denseSpinBox_valueChanged(const QString &arg1);

    void on_sCountEdit_editingFinished();

    void on_sCountEdit_textEdited(const QString &arg1);

    void on_pLengthEdit_editingFinished();

    void on_pWidthEdit_editingFinished();

    void saveScene();

    void showDialog();

    void on_actionSave_PNG_triggered();

    void on_actionFixed_size_toggled(bool arg1);

    void on_clScrButton_clicked();

private:
    Ui::MainWindow *ui;
    bool thereIsPlate, specksElliptic;
    int speckCount;
    float pWidth, pLength, speckDiam, minorRadius, majorRadius;
    double denseCoeff;
    QString pWidthStr, pLengthStr, speckDiamStr, denseCoeffStr, speckCountStr;
    float screenWidth, screenHeight;
    QBrush redBrush, blueBrush, whiteBrush;
    QPen blackPen, whitePen;
    QGraphicsScene *scene;
    QList<QGraphicsEllipseItem*>speckList;
    QGraphicsRectItem *rectangle;
    void printSceneDim();
    void readRadii();
    //Declaration of the menus
    /*QMenu *fileMenu;
    QMenu *editMenu;
    QAction *saveAct;
    QAction *showDialogAct;
    QAction *loadAct;*/
    EllipticFixedSize *dia;
};



#endif // MAINWINDOW_H
