#include "mainwindow.h"
#include "ui_mainwindow.h"

//All the things drawn are centered on the Graphicsview
//Care should be taken that the drawing size isn't greater than the the size of the graphicsView

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    thereIsPlate=false, specksElliptic=false;
    qsrand(QTime::currentTime().msec());
    screenWidth=ui->graphicsView->width();
    screenHeight=ui->graphicsView->height();
    redBrush.setColor(Qt::red);redBrush.setStyle(Qt::SolidPattern);
    blueBrush.setColor(Qt::blue);blueBrush.setStyle(Qt::SolidPattern);
    whiteBrush.setColor(Qt::white);
    blackPen.setColor(Qt::black);
    blackPen.setWidth(4);
    whitePen.setColor(Qt::white);
    //Default values for plate and speckle size
    pLength=500; pWidth=250, speckDiam=10;
    ui->pLengthEdit->setText("500");ui->pWidthEdit->setText("250");ui->sDiamEdit->setText("10");
    denseCoeff=1.0;
    speckCount=1000;
    //Creating the menus
    //fileMenu = menuBar()->addMenu(tr("&File"));
    //editMenu = menuBar()->addMenu(tr("&Edit"));
    //saveAct = new QAction(tr("&Save PNG"), this);
    //saveAct->setShortcuts(QKeySequence::Save);
    //saveAct->setStatusTip(tr("Save the scene as a PNG file"));
    //showDialogAct = new QAction(tr("&Show Dialog"), this);
    //showDialogAct->setStatusTip(tr("Show the dialog"));
    //loadAct = new QAction(tr("&Load"), this);
    //connect(saveAct, SIGNAL(triggered()), this, SLOT(saveScene()));
    //connect(showDialogAct, SIGNAL(triggered()), this, SLOT(showDialog()));
    //fileMenu->addAction(saveAct);
    //fileMenu->addAction(showDialogAct);
    //fileMenu->addAction(loadAct);
    dia = new EllipticFixedSize(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_closeButton_clicked()
{
    QMainWindow::close();
}
void MainWindow::on_pLengthEdit_editingFinished()
{
    pLengthStr = ui->pLengthEdit->text();
    pLength=pLengthStr.toFloat();
    qDebug() << "Length of the plate is: "<< pLength;
}

void MainWindow::on_pWidthEdit_editingFinished()
{
    pWidthStr = ui->pWidthEdit->text();
    this->pWidth=pWidthStr.toFloat();
    qDebug() << "Width of the plate is: "<< this->pWidth;
}

void MainWindow::on_sDiamEdit_textChanged(const QString &arg1)
{
    speckDiamStr = ui->sDiamEdit->text();
    this->speckDiam=speckDiamStr.toFloat();
    qDebug() << "Speckle diameter is: "<< this->speckDiam;
}

void MainWindow::on_denseSpinBox_valueChanged(const QString &arg1)
{
    if((ui->denseSpinBox->value()-0)>0.000001){
        denseCoeffStr = ui->denseSpinBox->text();
        this->denseCoeff=denseCoeffStr.toDouble();
        speckCount=speckCount*denseCoeff;
        qDebug()<<"The new speckCount is "<<speckCount;
        speckCountStr=QString::number(speckCount);
        ui->sCountEdit->setText(speckCountStr);
    }
}

void MainWindow::on_sCountEdit_editingFinished()
{
    speckCountStr=ui->sCountEdit->text();
    speckCount=speckCountStr.toInt();
}
void MainWindow::on_sCountEdit_textEdited(const QString &arg1)
{
    speckCountStr=ui->sCountEdit->text();
    speckCount=speckCountStr.toInt();
}

void MainWindow::on_cleanButton_clicked()
{
    scene->clear();
    ui->sCountEdit->clear();
    on_drPlateButton_clicked();
}
void MainWindow::on_clScrButton_clicked()
{
    scene->clear();
    ui->sCountEdit->clear();
    thereIsPlate=false;
}

void MainWindow::on_drPlateButton_clicked()
{
    scene=new QGraphicsScene(this);
    ui->graphicsView->setScene(scene);
    if(pWidth > pLength){
        QMessageBox::information(this, "Width of the plate can't be greater than its length.", "The values will be swapped");
        float *temp;temp=new float;
        *temp=pWidth;pWidth=pLength;pLength=*temp;delete temp;
    }
    if(pLength >= 0.8*screenWidth){
        float coeff = pLength/(0.8*screenWidth);
        pWidth=pWidth/coeff;
        pLength=0.8*screenWidth;
    }
    if (pWidth>=0.8*screenHeight){
        float coeff2 = pWidth/(0.8*screenHeight);
        pLength=pLength/coeff2;
        pWidth=0.8*screenHeight;
    }
    rectangle=scene->addRect(/*-screenWidth+10*/0, /*-screenHeight/2+10*/0, pLength, pWidth, blackPen, whiteBrush);
    //ui->graphicsView->centerOn(speckList[0]);
    thereIsPlate=true;
    pLengthStr = ui->pLengthEdit->text();
    this->pLength=pLengthStr.toFloat();
    pWidthStr = ui->pWidthEdit->text();
    this->pWidth=pWidthStr.toFloat();
    //this->printSceneDim();
    //qDebug()<<"The width of the graphicsView is: "<<screenWidth;
    //qDebug()<<"The height of the graphicsView is: "<<screenHeight;
}

void MainWindow::on_spButton_clicked()
{
    if (thereIsPlate==false){
        QMessageBox::information(this, "There is no plate to speckle", "Please draw the plate first");
        return;
    }
    on_cleanButton_clicked();
    readRadii();
    float randNum;
    float resultNum;
    float X, Y;
    QList<float> randomsW;QList<float> randomsL;
    for (int i=0; i< speckCount; i++){
        randNum=qrand();resultNum=randNum/RAND_MAX;
        randomsL.append(resultNum);
    }
    for (int i=0; i<speckCount; i++){
        randNum=qrand();resultNum=randNum/RAND_MAX;
        randomsW.append(resultNum);
    }
    //Adding circular speckles to the plate
    if(specksElliptic==false){
        for (int i=0; i<speckCount;i++){
            //Keeping the ellipses within the plate
            if(randomsL[i]*pLength-speckDiam < 0){
                X=randomsL[i]*pLength;
            }
            else{
                X=randomsL[i]*pLength-speckDiam;
            }
            if(randomsW[i]*pWidth-speckDiam < 0){
                Y=randomsW[i]*pWidth;
            }
            else{
                Y=randomsW[i]*pWidth-speckDiam;
            }
            speckList.append(scene->addEllipse(/*randomsL[i]*pLength-speckDiam*/X, /*randomsW[i]*pWidth-speckDiam*/Y, speckDiam, speckDiam,
                        QPen(), redBrush));
        }
    }
    //Adding elliptic speckles to the plate
    if(specksElliptic==true){
        for (int i=0; i<speckCount;i++){
            //Keeping the ellipses within the plate
            //Major axis in horizontal direction case
            if(dia->directionCount>1){
                QMessageBox::information(this, "You checked more than one speckle direction options", "Please select only one speckle direction option");
                return;
            }
            qDebug()<<"majorAxisHorizontal is "<<dia->majorAxisHorizontal;
            if(dia->majorAxisHorizontal==true){
                if(randomsL[i]*pLength-2*majorRadius < 0){
                    X=randomsL[i]*pLength;
                }
                else{
                    X=randomsL[i]*pLength-2*majorRadius;//most of the time this is used
                }
                if(randomsW[i]*pWidth-2*minorRadius < 0){
                    Y=randomsW[i]*pWidth;
                }
                else{
                    Y=randomsW[i]*pWidth-2*minorRadius;
                }
                speckList.append(scene->addEllipse(/*randomsL[i]*pLength-speckDiam*/X, /*randomsW[i]*pWidth-speckDiam*/Y, 2*majorRadius, 2*minorRadius,
                            QPen(), redBrush));
            }
            else if(dia->majorAxisVertical==true){
                if(randomsL[i]*pLength-2*minorRadius < 0){
                    X=randomsL[i]*pLength;
                }
                else{
                    X=randomsL[i]*pLength-2*minorRadius;//most of the time this is used
                }
                if(randomsW[i]*pWidth-2*majorRadius < 0){
                    Y=randomsW[i]*pWidth;
                }
                else{
                    Y=randomsW[i]*pWidth-2*majorRadius;
                }
                speckList.append(scene->addEllipse(/*randomsL[i]*pLength-speckDiam*/X, /*randomsW[i]*pWidth-speckDiam*/Y, 2*minorRadius, 2*majorRadius,
                            QPen(), redBrush));
            }
            //Major axis in vertical direction case
        }
    }
    speckList.clear();
    qDebug()<<"The number of speckles: "<<speckCount;
    speckCountStr=QString::number(speckCount);
    ui->sCountEdit->setText(speckCountStr);
    //qDebug()<<"The width of the graphicsView is: "<<screenWidth;
    //qDebug()<<"The height of the graphicsView is: "<<screenHeight;
}
void MainWindow::printSceneDim()
{
    qDebug()<<"The width of the scene is: "<<scene->width();
    qDebug()<<"The height of the scene is: "<<scene->height();
}

void MainWindow::readRadii()
{
    if (dia->minorRadiusStr!=""){
        minorRadius=dia->minorRadiusStr.toFloat();
        qDebug()<<"the minor radius is: "<<minorRadius;
        ui->sDiamEdit->setText("");
    }
    if (dia->majorRadiusStr!=""){
        majorRadius=dia->majorRadiusStr.toFloat();
        qDebug()<<"the major radius is: "<<majorRadius;
        ui->sDiamEdit->setText("r1="+dia->minorRadiusStr+", r2="+dia->majorRadiusStr);
        specksElliptic=true;
    }
}
void MainWindow::saveScene(){
    QImage img(1024,768,QImage::Format_ARGB32_Premultiplied);
    QPainter p(&img);
    scene->render(&p);
    p.end();
    img.save("XXX.png");
}

void MainWindow::showDialog()
{
    if (dia->isVisible()==false){
        dia->show();
    }
    //MyDialog mD;
    //mD.setModal(true); Background is deactivated
    //mD.exec();
}

void MainWindow::on_actionSave_PNG_triggered()
{
    QImage img(1024,768,QImage::Format_ARGB32_Premultiplied);
    QPainter p(&img);
    scene->render(&p);
    p.end();
    img.save("XXX.png");
}

void MainWindow::on_actionFixed_size_toggled(bool arg1)
{
    if (dia->isVisible()==false){
        dia->show();
    }
}
